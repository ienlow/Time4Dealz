package com.example.isaacenlow.time4dealz;

class Player {

    String name;
    String url;
    Player(String _name, String _url) {
        name = _name;
        url = _url;
    }
}