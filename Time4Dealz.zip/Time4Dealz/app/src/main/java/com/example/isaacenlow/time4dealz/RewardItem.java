package com.example.isaacenlow.time4dealz;

public class RewardItem {
    String discount = "";
    int points;
    public RewardItem(String discount, int points) {
        this.discount = discount;
        this.points = points;
    }
}
